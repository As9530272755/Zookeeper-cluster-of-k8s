#!/bin/bash
docker build -t 192.168.7.206/baseimages/my-zookeeker:3.4.12 .
docker push 192.168.7.206/baseimages/my-zookeeker:3.4.12
